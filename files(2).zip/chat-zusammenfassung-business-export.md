# ChatGPT Business Export Tool - Entwicklungs-Zusammenfassung

**Datum**: 13. Dezember 2025  
**Kontext**: Weiterentwicklung eines Python-Scripts zum Export von ChatGPT Business Account Conversations

## Ausgangssituation

### Bestehendes Script (v1)
- Entwickelt am 27. November 2024
- Export von ChatGPT Business Chats via Playwright
- Features: Markdown, PDF, Screenshots, Metadaten, Keyword-Suche
- **Probleme**:
  - Erster Chat wird leer exportiert
  - UI-Änderungen bei ChatGPT
  - Keine Unterstützung für Projektordner
  - Unvollständige Metadaten

## Entwickelte Lösung (v2)

### Neue Features

#### 1. Projekt-Support
**Problem**: ChatGPT Business hat Projektordner, Script konnte nur Chats außerhalb exportieren

**Lösung**:
- CLI-Parameter: `--project "Projektname"`
- URL-basierte Filterung:
  - Normale Chats: `https://chatgpt.com/c/CHAT-ID`
  - Projekt-Chats: `https://chatgpt.com/g/g-p-PROJECT-ID/c/CHAT-ID`
- Navigation zum Projekt via Selektor: `nav a:has-text("Projektname")`
- Filterung nach URL-Muster `/g/g-p-` für Projekt-Chats

**Code-Snippet**:
```python
async def get_chat_links(page, in_project=False):
    all_links = await page.locator('a[href*="/c/"]').all()
    
    if in_project:
        project_links = []
        for link in all_links:
            href = await link.get_attribute("href")
            if href and "/g/g-p-" in href:
                project_links.append(link)
        return project_links
    else:
        normal_links = []
        for link in all_links:
            href = await link.get_attribute("href")
            if href and "/g/g-p-" not in href:
                normal_links.append(link)
        return normal_links
```

#### 2. Optionale Keywords
**Problem**: Keywords waren fest im Code verdrahtet

**Lösung**:
- CLI-Parameter: `--keywords WORD1 WORD2 "Multi Word"`
- Keywords werden nur verwendet wenn angegeben
- Keyword-Screenshots nur bei Angabe von Keywords
- Metadaten enthalten "keywords_found" nur wenn Keywords gesucht wurden

**Code-Snippet**:
```python
parser.add_argument(
    '--keywords',
    nargs='+',
    help='Keywords zum Suchen und für Keyword-Screenshots'
)
```

#### 3. Dynamische Verzeichnisnamen
**Problem**: Exportverzeichnis hatte immer gleichen Namen

**Lösung**:
```python
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
export_name_parts = ["chatgpt_business_export"]

if project_name:
    clean_project = slug(project_name)
    export_name_parts.append(f"project_{clean_project}")

if keywords:
    keywords_str = "_".join([slug(kw) for kw in keywords[:3]])
    export_name_parts.append(f"kw_{keywords_str}")

export_name_parts.append(timestamp)
export_dir = pathlib.Path("_".join(export_name_parts))
```

**Beispiele**:
- Ohne Parameter: `chatgpt_business_export_20251213_155623`
- Mit Projekt: `chatgpt_business_export_project_mcp_20251213_155623`
- Mit Keywords: `chatgpt_business_export_kw_nrw_owl_20251213_155623`
- Beides: `chatgpt_business_export_project_mcp_kw_nrw_owl_20251213_155623`

#### 4. Verbesserte Chat-Extraktion
**Problem**: Erste Chats wurden als leer erkannt

**Lösung**: Mehrere Selektoren mit Fallback-Strategie
```python
selectors = [
    'main [data-testid="conversation-turn"]',
    'main [data-message-author-role]',
    'main article',
    'main div[class*="group"]',  # Neue UI
]

for selector in selectors:
    elements = await page.locator(selector).all()
    if elements and len(elements) > 0:
        print(f"  Turns gefunden mit: {selector}")
        break
```

#### 5. Immer Metadaten
**Problem**: Metadaten wurden nicht für alle Chats generiert

**Lösung**: 
- `SAVE_METADATA` Flag entfernt
- Metadaten werden IMMER generiert
- Inklusive Projekt-Name im Metadaten-JSON

### CLI-Optionen

```bash
# Nur Chats außerhalb von Projekten
python export_enhanced_v2.py

# Nur Chats aus Projekt
python export_enhanced_v2.py --project "MCP"

# Alle Chats (inkl. Projekte)
python export_enhanced_v2.py --all

# Mit Keywords
python export_enhanced_v2.py --keywords NRW "Bad Sassendorf"

# Kombiniert
python export_enhanced_v2.py --project "MCP" --keywords NRW OWL
```

## Technische Details

### Wichtige Funktionen

1. **`navigate_to_project(page, project_name)`**
   - Sucht Projekt in Sidebar
   - Prüft URL-Änderung für erfolgreiche Navigation
   - Mehrere Selektoren als Fallback

2. **`get_chat_links(page, in_project=False)`**
   - Holt alle Chat-Links
   - Filtert nach URL-Muster je nach Modus
   - Unterscheidet Projekt- vs. normale Chats

3. **`export_chat(page, dirs, project_name, keywords)`**
   - Exportiert einzelnen Chat
   - Speichert Markdown, PDF, HTML, Screenshots
   - Generiert Metadaten mit Hash

4. **`save_chat_metadata(..., keywords=None)`**
   - SHA256-Hash des Markdown-Inhalts
   - Projekt-Name in Metadaten
   - Optional: Keywords-Found-Liste

### Metadaten-Format

```json
{
  "export_timestamp": "2025-12-13T15:56:23",
  "chat_timestamp": "2025-12-13T15-56-23",
  "chat_url": "https://chatgpt.com/g/g-p-xxx/c/abc123",
  "chat_title": "beispiel-chat",
  "project": "MCP",
  "user_agent": "Mozilla/5.0...",
  "account_info": "ChatGPT Business Account",
  "sha256_markdown": "a1b2c3...",
  "browser": "Chrome",
  "keywords_found": ["NRW", "OWL"]
}
```

## Ordnerstruktur Export

```
chatgpt_business_export_project_mcp_20251213_155623/
├── markdown/
│   └── chat-title-2025-12-13T15-56-23.md
├── pdf/
│   └── chat-title-2025-12-13T15-56-23.pdf
├── metadata/
│   └── chat-title-2025-12-13T15-56-23.json
├── screenshots/
│   ├── chat-title-2025-12-13T15-56-23-full.png
│   └── chat-title-2025-12-13T15-56-23-keyword-nrw.png
├── raw_html/
│   └── chat-title-2025-12-13T15-56-23.html
└── export_info.json
```

## GitHub Repository Struktur

```
chatgpt-business-export/
├── export_enhanced_v2.py    # Haupt-Script
├── README.md                # Dokumentation
├── LICENSE                  # MIT License
├── .gitignore              # Git-Ignore-Regeln
├── requirements.txt        # Dependencies
└── GITHUB_SETUP.md         # Setup-Anleitung
```

## Adaptierung für ChatGPT PLUS

### Unterschiede Business vs. PLUS

| Feature | Business | PLUS |
|---------|----------|------|
| Projekte | ✓ Ja | ✗ Nein |
| URL-Struktur | `/g/g-p-PROJECT/c/ID` | `/c/ID` |
| Account-Typ | Business Workspace | Persönlich |
| Team-Features | ✓ Ja | ✗ Nein |

### Anpassungen für PLUS

1. **Projekt-Support entfernen**:
   - `--project` Parameter nicht nötig
   - `--all` Parameter nicht nötig
   - Nur normale Chat-URLs: `/c/ID`

2. **URL-Filterung vereinfachen**:
   ```python
   # Für PLUS: Keine Filterung nötig
   async def get_chat_links(page):
       return await page.locator('a[href*="/c/"]').all()
   ```

3. **Metadaten anpassen**:
   ```json
   {
     "account_info": "ChatGPT Plus Account",
     "project": "None"  // Immer None bei PLUS
   }
   ```

4. **Verzeichnisname**:
   ```python
   # Für PLUS
   export_name_parts = ["chatgpt_plus_export"]
   # Kein "project_" Teil
   ```

5. **CLI vereinfachen**:
   ```bash
   # Nur diese Optionen:
   python export_plus.py
   python export_plus.py --keywords NRW OWL
   ```

### Code-Änderungen für PLUS

**Zu entfernen**:
- `--project` Parameter
- `--all` Parameter
- `navigate_to_project()` Funktion
- URL-Filterung nach `/g/g-p-`
- `in_project` Parameter überall

**Zu ändern**:
- Account-Typ in Metadaten: "ChatGPT Plus Account"
- Export-Verzeichnis: `chatgpt_plus_export_*`
- README anpassen (keine Projekt-Erwähnungen)

**Beizubehalten**:
- Keywords-Support
- Screenshot-Funktion
- Metadaten mit Hash
- PDF/Markdown/HTML Export
- Backup-Funktionalität

## Lessons Learned

### 1. URL-Muster sind zuverlässiger als DOM-Selektoren
ChatGPT ändert oft UI/CSS, aber URL-Struktur bleibt stabil:
- Projekt-Chats: `/g/g-p-PROJECT-ID/c/CHAT-ID`
- Normale Chats: `/c/CHAT-ID`

### 2. Mehrere Selektoren als Fallback
UI-Änderungen brechen einzelne Selektoren, daher immer mehrere probieren:
```python
for selector in [sel1, sel2, sel3]:
    elements = await page.locator(selector).all()
    if elements:
        break
```

### 3. CLI-Parameter für Flexibilität
Statt feste Konfiguration im Code, CLI-Parameter für:
- Projekt-Auswahl
- Keywords
- Modi (--all)

### 4. Dynamische Verzeichnisnamen für Übersicht
Parameter im Verzeichnisnamen erleichtert später die Zuordnung

### 5. Metadaten IMMER generieren
Für forensische Zwecke und GDPR-Compliance unverzichtbar

## Testing

### Getestete Szenarien
- ✓ Export ohne Parameter (nur normale Chats)
- ✓ Export mit `--project "MCP"` (nur Projekt-Chats)
- ✓ Export mit `--keywords NRW OWL`
- ✓ Kombiniert: `--project "MCP" --keywords NRW`
- ✓ Dynamische Verzeichnisnamen
- ✓ Metadaten-Generierung für alle Chats

### Bekannte Probleme
- PDF-Export schlägt manchmal fehl (nicht kritisch, MD/HTML bleiben)
- Cloudflare-CAPTCHA muss manuell gelöst werden
- Chrome muss vor Start komplett geschlossen sein

## Nächste Schritte für ChatGPT PLUS Version

1. **Script kopieren**: `export_enhanced_v2.py` → `export_plus.py`
2. **Projekt-Code entfernen**: Alle Projekt-bezogenen Funktionen
3. **URL-Filterung vereinfachen**: Keine `/g/g-p-` Prüfung
4. **README anpassen**: PLUS-spezifische Dokumentation
5. **Testen**: Mit ChatGPT PLUS Account
6. **Separates Repository**: `chatgpt-plus-export`

## Dateien zum Übertragen

Für GitHub Upload:
- ✓ `export_enhanced_v2.py` - Haupt-Script
- ✓ `README.md` - Dokumentation
- ✓ `LICENSE` - MIT License
- ✓ `.gitignore` - Ignore-Regeln
- ✓ `requirements.txt` - Dependencies
- ✓ `GITHUB_SETUP.md` - Setup-Guide

---

**Version**: 2.0  
**Entwickelt**: 13. Dezember 2025  
**Entwickler**: Andy Post  
**Zweck**: Account-Tracking-Dokumentation, GDPR-Compliance
