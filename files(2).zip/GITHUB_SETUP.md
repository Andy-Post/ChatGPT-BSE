# GitHub Repository Setup - Anleitung

## Schritt 1: Repository auf GitHub erstellen

1. Gehe zu https://github.com
2. Klicke auf das **+** Symbol oben rechts
3. Wähle **New repository**
4. Fülle aus:
   - **Repository name**: `chatgpt-business-export`
   - **Description**: `Automated export tool for ChatGPT Business Account conversations with project support`
   - **Public** oder **Private** - deine Wahl
   - **NICHT** "Initialize with README" ankreuzen (haben wir schon)
5. Klicke **Create repository**

## Schritt 2: Dateien hochladen

### Option A: Via Browser (einfach)

1. Auf der leeren Repository-Seite, klicke **uploading an existing file**
2. Ziehe folgende Dateien in das Upload-Feld:
   - `export_enhanced_v2.py`
   - `README.md`
   - `LICENSE`
   - `.gitignore`
   - `requirements.txt`
3. Commit message: `Initial commit - ChatGPT Business Export Tool v2`
4. Klicke **Commit changes**

### Option B: Via Git CLI (für Fortgeschrittene)

```bash
cd E:\ChatGPT-Business
git init
git add export_enhanced_v2.py README.md LICENSE .gitignore requirements.txt
git commit -m "Initial commit - ChatGPT Business Export Tool v2"
git branch -M main
git remote add origin https://github.com/DEIN-USERNAME/chatgpt-business-export.git
git push -u origin main
```

## Schritt 3: Repository-Einstellungen (Optional)

### Topics hinzufügen
1. Gehe zu deinem Repository
2. Klicke auf das Zahnrad-Symbol bei "About"
3. Füge Topics hinzu:
   - `chatgpt`
   - `export-tool`
   - `playwright`
   - `python`
   - `automation`
   - `backup`
   - `gdpr`

### README-Anpassungen
Bearbeite `README.md` direkt auf GitHub:
- Ersetze `DEIN-USERNAME` mit deinem GitHub-Username
- Ersetze `DEIN-USER` mit deinem Windows-Username

### GitHub Actions (Optional)
Falls du später automatische Tests möchtest, kannst du GitHub Actions einrichten.

## Dateistruktur im Repository

```
chatgpt-business-export/
├── export_enhanced_v2.py    # Haupt-Script
├── README.md                # Dokumentation
├── LICENSE                  # MIT License
├── .gitignore              # Git-Ignore-Regeln
└── requirements.txt        # Python Dependencies
```

## Nach dem Upload

1. **README überprüfen**: Gehe zu deinem Repository und schaue ob README korrekt angezeigt wird
2. **Clone testen**: Teste ob du das Repo clonen kannst
3. **Issues aktivieren**: Settings > Features > Issues (falls noch nicht aktiv)
4. **Releases erstellen**: Später kannst du unter "Releases" Versionen taggen

## Repository-URL

Nach dem Erstellen ist dein Repository verfügbar unter:
```
https://github.com/DEIN-USERNAME/chatgpt-business-export
```

## Weitere Updates hochladen

Wenn du später Änderungen machst:
1. Gehe zu deinem Repository
2. Klicke auf die Datei die du ändern willst
3. Klicke auf das Stift-Symbol (Edit)
4. Mache deine Änderungen
5. Commit changes

## Nächste Schritte

- [ ] Repository erstellt
- [ ] Dateien hochgeladen
- [ ] README angepasst
- [ ] Topics hinzugefügt
- [ ] Ersten Release erstellen (optional)
